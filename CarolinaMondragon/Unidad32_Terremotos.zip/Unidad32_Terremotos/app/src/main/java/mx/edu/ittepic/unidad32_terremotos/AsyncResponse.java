package mx.edu.ittepic.unidad32_terremotos;

public interface AsyncResponse {
    void procesarRespuesta(String r);
}