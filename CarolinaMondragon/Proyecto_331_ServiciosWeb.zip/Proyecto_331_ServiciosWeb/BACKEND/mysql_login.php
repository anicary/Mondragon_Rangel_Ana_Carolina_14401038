<?php
/**
 * Provee las constantes para conectarse a la base de datos
 * Mysql.
 */
define("HOSTNAME", "198.91.81.5");// Nombre del host
define("DATABASE", "carostor_alumnos"); // Nombre de la base de datos
define("USERNAME", "carostor_caro"); // Nombre del usuario
define("PASSWORD", "Quesito02"); // Nombre de la constraseña
/*
define("HOSTNAME", "localhost");// Nombre del host
define("DATABASE", "Alumnos"); // Nombre de la base de datos
define("USERNAME", "root"); // Nombre del usuario
define("PASSWORD", ""); // Nombre de la constraseña
*/

?>
