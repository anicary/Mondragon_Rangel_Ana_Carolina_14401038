package mx.edu.ittepic.proyecto_331_serviciosweb.Utilidades;

public interface AsyncResponse {
    void procesarRespuesta(String r);
}