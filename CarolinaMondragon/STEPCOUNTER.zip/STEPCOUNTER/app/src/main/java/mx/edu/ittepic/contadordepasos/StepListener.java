package mx.edu.ittepic.contadordepasos;


public interface StepListener{
    public void step(long timeNs);
}