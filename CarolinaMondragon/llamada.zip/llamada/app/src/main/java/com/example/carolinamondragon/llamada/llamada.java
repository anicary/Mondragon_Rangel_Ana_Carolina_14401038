package com.example.carolinamondragon.llamada;

import android.provider.CallLog;

/**
 * Created by Carolina Mondragon on 20/05/2018.
 */

public class llamada {
    String numero;
    String duracion;

    public llamada(String numero, String duracion) {
        this.numero = numero;
        this.duracion = duracion;
    }

    public llamada() {

    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getDuracion() {
        return duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }
}
