package com.example.carolinamondragon.llamada;

import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.Manifest;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity{

    Button res,call;
    TextView txtllamada;
    List<llamada> listallamada;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        res = (Button) findViewById(R.id.btnrespaldo);
        call =(Button) findViewById(R.id.llamadas);
        listallamada=new ArrayList<llamada>();
        txtllamada =(TextView) findViewById(R.id.txtllamadas);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
        }else
        {

        }

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObtenerDatosLlamadas();
            }
        });
        res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference bd = FirebaseDatabase.getInstance().getReference("Llamadas");
                for(int i=0;i<listallamada.size();i++){
                    bd.push().setValue(listallamada.get(i));
                }
            }
        });

    }

    public void ObtenerDatosLlamadas() {

        Uri uri;
        uri = Uri.parse("content://call_log/calls");

        String[] projeccion = new String[]{ CallLog.Calls.NUMBER, CallLog.Calls.DURATION};
        Cursor c = getContentResolver().query(
                uri,
                projeccion,
                null,
                null,
                null);

        txtllamada.setText("");


        while(c.moveToNext()){
            txtllamada.append(" Número: " + c.getString(0) + " Duración: " + c.getString(1) +"\n");
            listallamada.add(new llamada(c.getString(0),c.getString(1)));
        }
        c.close();


    }

    public void ObtenerDatos(){

        String[] projeccion = new String[] { ContactsContract.Data._ID, ContactsContract.Data.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.TYPE };
        String selectionClause = ContactsContract.Data.MIMETYPE + "='" +
                ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE + "' AND "
                + ContactsContract.CommonDataKinds.Phone.NUMBER + " IS NOT NULL";
        String sortOrder = ContactsContract.Data.DISPLAY_NAME + " ASC";

        Cursor c = getContentResolver().query(
                ContactsContract.Data.CONTENT_URI,
                projeccion,
                selectionClause,
                null,
                sortOrder);

        txtllamada.setText("");


        while(c.moveToNext()){
            txtllamada.append("Identificador: " + c.getString(0) + " Nombre: " + c.getString(1) + " Número: " + c.getString(2)+  " Tipo: " + c.getString(3)+"\n");
        }
        c.close();


    }

    }