package mx.edu.ittepic.contadordepasos;



import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.prefs.Preferences;

public class MainActivity extends AppCompatActivity  implements SensorEventListener, StepListener {


    private TextView textView;
    public StepDetector simpleStepDetector;
    public SensorManager sensorManager;
    public Sensor accel;
    private int numSteps;


    Sensor countSensor;
    Button[] options;
    boolean isPause=false;

    CountDownTimer relog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView=(TextView)findViewById(R.id.cnt);
        options= new Button[2];
        options[0]=(Button)findViewById(R.id.Puase);
        options[1]=(Button)findViewById(R.id.Reset);


        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        simpleStepDetector = new StepDetector();
        simpleStepDetector.registerListener(MainActivity.this);

        textView=(TextView)findViewById(R.id.cnt);

        numSteps = 0;
        sensorManager.registerListener(MainActivity.this, accel, SensorManager.SENSOR_DELAY_FASTEST);


        options[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isPause){

                    options[0].setText("Pausar");
                    isPause=false;

                }else
                {
                    options[0].setText("Contar");
                    isPause=true;

                }
            }
        });
        options[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                numSteps=0;
            }
        });
        relog= new CountDownTimer(5000,100) {
            @Override
            public void onTick(long l) {
                textView.setText(""+ numSteps);
            }

            @Override
            public void onFinish() {
                start();
            }
        }.start();
    }


    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            simpleStepDetector.updateAccel(
                    sensorEvent.timestamp, sensorEvent.values[0], sensorEvent.values[1], sensorEvent.values[2]);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }


    @Override
    public void step(long timeNs) {
        if(!isPause){
            int i = numSteps++;
            textView.setText(i+"");
        }

    }

}
